package calcnet;

import java.awt.EventQueue;

import calculator.Equation;
import calculator.GUI;
import imgprocessing.ProcessImg;
import textnet.TextNet;

public class Main 
{
	static GUI frame = new GUI();
	static ProcessImg trim = new ProcessImg();
	static TextNet net = null;
	static calculator.Main calculator = new calculator.Main();
	static Equation equation = new Equation();
	static float[] data = new float[784];
	
	public static void main(String[] args)
	{
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame = new GUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		//while(true)
		{
			System.out.print("here");
			while(!frame.isDone())
			{
				System.out.print(frame.isDone());
				try {
					Thread.sleep(10);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			equation = frame.getEquation();
			while(equation.getWrittens().size() > 0)
			{
				equation.getWrittens().get(0).getData().getPixels(0, 0, 28, 28, data);
				equation.getWrittens().remove(0);
				net.main(data);
			}
			equation.set();
			frame.setResult(calculator.run(equation));
		}
	}
}
