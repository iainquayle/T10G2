package calcnet;

import java.awt.EventQueue;

import calculator.Equation;
import calculator.GUI;
import imgprocessing.ProcessImg;
import textnet.TextNet;

public class Main 
{
	static GUI frame = new GUI();
	static ProcessImg trim = new ProcessImg();
	static TextNet net = null;
	static calculator.Main calculator = new calculator.Main();
	static Equation equation = new Equation();
	
	public static void main(String[] args)
	{
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame = new GUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		while(true)
		{
			while(!frame.isDone())
			{
			}
			equation = frame.getEquation();
			while(equation.getWrittens().size() > 0)
			{
				net.main(null);
			}
			equation.set();
			frame.setResult(calculator.run(equation));
		}
	}
}
