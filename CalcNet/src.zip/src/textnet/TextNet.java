package textnet;

import java.lang.System;
import java.lang.Thread;
import java.lang.Runnable;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.Random;
import java.io.File;
import java.io.IOException;
@SuppressWarnings("unused")

public class TextNet
{
	private static Thread thread = Thread.currentThread();
	
	private static Layer[] layers = null;
	
	private static String loc = System.getProperty("user.dir") + "\\";
	private static String netName = null;
	private static String dataName = null;
	
	private static float[][] ioPuts = null;
	private static Random rnd = new Random();
	private static int lenIoPuts = 0;
	private static int lenLayers = 0;
	
	public TextNet(String net)
	{
		netName = net;
		try 
		{
			init();
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		}
	}
	
	public int main(float[] data) 
	{		
		return run();
	}
	
	public static void init() throws IOException
	{
		//loading and initializing net architecture and weights 
		System.out.println("Init");
		int temp = 0;
		InputData file = new InputData(loc + netName + "\\" + netName + ".csv");
		lenLayers = file.nextInt();
		layers = new Layer[lenLayers];
		for(int i = 0; i < lenLayers; i++)
		{
			temp = file.nextInt();
			if(temp == 0)
			{
				layers[i] = new Dense();
			}
			else if(temp == 1)
			{
				layers[i] = new Conv2D();
			}
			else if(temp == 2)
			{
				//layers[i] = new Input();
			}
			else if(temp == 3)
			{
				layers[i] = new InDense();
			}
			else if(temp == 4)
			{
				layers[i] = new InConv2D();
			}
			else if(temp == 5)
			{
				//layers[i] = new Output();
			}
			else if(temp == 6)
			{
				layers[i] = new OutDense();
			}
			else if(temp == 7)
			{
				layers[i] = new MaxPool();
			}
		}
		temp = 0;
		//initializing individual layers
		for(int i = 0; i < lenLayers; i++)
		{
			System.out.println("Init layer " + i);
			layers[i].init(layers, loc + netName + "\\" + netName, file, ioPuts, i);
			temp += layers[i].getLenVals();
		}
		layers[0].setStatRefs(new float[temp], new float[temp]);
		file.close();
		System.gc();
	}
	//saves layers current weights
	public static void save() throws IOException
	{
		System.out.println("Save");
		for(int i = 0; i < lenLayers; i++)
		{
			System.out.println("Save Layer" + i);
			layers[i].save(loc + netName + "\\" + netName);
		}
	}
	
	public static int run()
	{
		for(int j = 0; j < lenLayers; j++)
		{
			layers[j].eval();
			//System.out.println("Eval " + j);
		}
		return layers[0].getResult();
	}
	
	//print out configuration of net
	public static void print()
	{
		String str = "";
		for(int i = 0; i < lenLayers; i++)
		{
			str += layers[i];
		}
		System.out.println(str);
	}
}
