package imgprocessing;

import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class ProcessImg {
	private final int reqWidth = 28;
	private final int reqHeight = 28;
	private int reqX1;
	private int reqX2;
	private int reqX3;
    private int reqX4;
    private int reqY1;
    private int reqY2;
    private int reqY3;
    private int reqY4;

	public BufferedImage run(BufferedImage img) throws IOException {
    	ImgScanner scan = new ImgScanner();
		ImgOperations operate = new ImgOperations();
		reqX1 = scan.getreqX1(img);
    	reqX2 = scan.getreqX2(img);
    	reqX3 = scan.getreqX3(img);
    	reqX4 = scan.getreqX4(img);
    	reqY1 = scan.getreqY1(img);
    	reqY2 = scan.getreqY2(img);
    	reqY3 = scan.getreqY3(img);
    	reqY4 = scan.getreqY4(img);

    	int width = reqX1-reqX2;
    	int height = reqY4-reqY3;
    	if (width< 50 && height < 50) {
    		width = 50;
    		height = 50;
    	} else if (height < 50) {
    		height = width;

		} else if (width < 50) {
			width = height;
		}

	
		//System.out.println(inImg.getHeight());

		img = operate.cropImg(img, reqX2,reqY3, width, height);
        img = operate.resize(img, reqWidth, reqHeight);
        return img;

    }


}
